# Part D - team project story
# Story: As a registered user, I want to log in so that I can access my account.

Feature: User login
  As a registered user
  I want to log in
  So that I can access my account

  Background:
    Given a registered user "dareen278" with password "Secret#123"

  # Scenario 1 - happy path
  Scenario: Log in with correct credentials
    When the user logs in as "dareen278" with password "Secret#123"
    Then the login is successful
    And the user sees their dashboard

  # Scenario 2 - refused / error case
  Scenario: Refuse a wrong password
    When the user logs in as "dareen278" with password "wrong"
    Then the login is refused with "invalid username or password"
    And the user stays on the login page

  # Scenario 3 - edge cases via outline
  Scenario Outline: Account lock after failed attempts
    Given the user has <failed> failed login attempts
    When the user logs in as "dareen278" with password "wrong"
    Then the account status is "<status>"

    Examples:
      | failed | status |
      | 0      | active |
      | 1      | active |
      | 2      | locked |
