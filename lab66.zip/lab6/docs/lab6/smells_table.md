# Task C1 - Smells in legacy_invoice.py

| Smell | Where | Principle it breaks |
|---|---|---|
| Long if/elif chain on `kind` (written twice) | Loop body and after the loop | OCP: a new student type means editing this function in two places |
| Magic numbers (1200, 0.5, 2000, 5000) | Fee lines | Readability: nobody knows what the numbers mean or where to change a fee |
| One function calculates the fee, formats text, writes a file and prints | Whole function | SRP: four reasons to change in one place |
| File opened without `with` and closed by hand | `open` / `close` | Resource safety: the file stays open if `write` raises an error |
| Disk and `print` hard-wired inside the function | End of function | DIP: depends on the concrete disk, so it can't be tested without creating files |
| Fee calculated per course although only total hours matter | The `for` loop | Needless complexity / duplicated logic |
| Unknown `kind` silently produces a total of 0 | No `else` branch | Hidden bug: the refactored version raises `KeyError` instead (the one intended behaviour change) |

## Task A1 - does 100% coverage prove the code is correct?
No. 100% coverage only shows that every line ran during the tests; it does not show the assertions check the right behaviour, and it cannot reveal rules that have no test at all.
